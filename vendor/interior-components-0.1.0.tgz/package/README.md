# @interior/components

Copy-paste-grade React UX components built on **motion** and **Tailwind CSS v4**.

54 interactive components — accordions, drawers, command palettes, swipe decks,
OTP inputs, loading buttons and more — each self-contained, zero runtime
dependencies beyond `react` and `motion`.

## Install

```bash
npm install @interior/components
```

Peer requirements:

- `react` >= 18 (React 19 supported)
- `motion` >= 12
- `tailwindcss` v4 in your app (components use standard Tailwind palette
  classes, e.g. `bg-stone-100`, `dark:text-stone-200`, plus `motion` inline
  styles — no custom tokens required)

> Components use the `dark:` variant. If you use class-based dark mode, add
> `@custom-variant dark (&:where(.dark, .dark *));` to your CSS, exactly like
> Tailwind v4 recommends.

## Usage

Two import modes are supported.

### 1. Single component (shadcn-style, source)

Import straight from the raw `.tsx` source — your bundler compiles it, and the
`"use client"` directive is preserved:

```tsx
import { Accordion } from "@interior/components/accordion";
import { Drawer } from "@interior/components/drawer";
```

### 2. Bundled barrel (dist)

Import from the built ESM/CJS bundle:

```tsx
import { Accordion, Drawer, Modal } from "@interior/components";
```

The dist bundle is tree-shakeable (`sideEffects: false`). In Next.js apps the
barrel is marked `"use client"` so it works from server components too.

## Components

| Category | Components |
| --- | --- |
| Action Feedback | CopyButton, LoadingButton, HoldToConfirm, LikeBurst, Ripple, IconMorph, PressDepth |
| Input | FloatingLabelInput, InlineValidation, PasswordStrength, OtpInput, TagInput, ExpandingSearch |
| Async | HideOnScroll, LoadMore, SkeletonSwap, StreamingText, TypingIndicator, NewItemsPill, StickyHeader, ReadingProgress, LiveActivity |
| Selection | Tabs, SegmentedControl, FilterGrid, ValueFlash, PollResults |
| Gesture | SliderDetents, SwipeDeck, ReorderList, LongPressButton, Lightbox |
| Content | TextReveal, LogoMarquee, BlurUpImage, ShowMore |
| …and more | Modal, Drawer, Popover, Dropdown, ContextMenu, TooltipGroup, CommandPalette, PresenceAvatars, ProgressBar, ScrollSpy, SortableTable, SnapCarousel, WizardSteps, TaskSteps, … |

Every component ships with its own demo and documented props in the
[interior.dev](https://interior.dev) registry.

## Development

This is a workspace inside the `interior-components` monorepo.

```bash
npm install
npm run build --workspace @interior/components   # tsup → dist/
npm run typecheck --workspace @interior/components
npm run lint --workspace @interior/components
```

## License

MIT
